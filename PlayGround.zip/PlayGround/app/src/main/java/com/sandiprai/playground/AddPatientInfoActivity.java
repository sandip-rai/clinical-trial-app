package com.sandiprai.playground;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AddPatientInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient_info);
    }
}
